import json
import requests


def _request(method, url, data=None):
    try:
        if method == "OPTIONS":
            response = requests.options(url)
        elif method == "GET":
            response = requests.get(url)
        elif method == "POST":
            headers = {'Content-Type': 'application/json'}
            response = requests.post(url, json=data, headers=headers)
        else:
            raise ValueError("Unsupported HTTP method")
        
        output = f"\n{method} Request\n"
        if method in ["GET", "POST"] and data:
            output += f"Request Data: {json.dumps(data, indent=2)}\n"
        
        output += (
            f"Status Code: {response.status_code}\n"
            f"Headers: {json.dumps(dict(response.headers), indent=2)}\n"
        )
        if response.content:
            output += f"Body: {json.dumps(response.json(), indent=2)}\n"
        else:
            output += "Body: (empty)\n"
        
        print(output)
        return output
    
    except Exception as e:
        error_msg = f"Error in {method} request: {str(e)}"
        print(error_msg)
        return error_msg


def main():
    url = "https://httpbin.org"
    results = []
    
    results.append(_request("OPTIONS", url + "/get"))
    
    results.append(_request("GET", url + "/get"))
    
    post_data = {"name": "Alex Sagitov", "email": "sagitov@pochta.ru"}
    results.append(_request("POST", url + "/post", post_data))

    with open("output.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(results))
    print("Results saved to 'output.txt'")


if __name__ == "__main__":
    main()
